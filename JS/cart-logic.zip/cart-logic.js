document.addEventListener("DOMContentLoaded", () => {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  const container = document.querySelector("#cartSection");
  let total = 0;

  const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  const userId = currentUser ? currentUser.userId : null;

  cart = cart.filter((item) => item.customerId == userId);

  function renderCart() {
    let output = `
        <h3 class="mb-4">Cart Items</h3>
        <div class="cart-head row fw-bold text-center d-none d-md-flex border-bottom pb-2">
          <div class="col-md-3 h4">Item Details</div>
          <div class="col-md-2 h4">Price</div>
          <div class="col-md-2 h4">Quantity</div>
          <div class="col-md-3 h4">Total Price</div>
          <div class="col-md-2 h4">Remove</div>
        </div>
    `;

    total = 0;

    cart.forEach((item, index) => {
      const cleanPrice = parseFloat(item.price.toString().replace(/,/g, ""));
      const itemTotal = cleanPrice * item.quantity;
      total += itemTotal;

      output += `
        <div class="cart-item row align-items-center text-center py-3 border-bottom del-item" data-index="${index}">
          <div class="col-12 col-md-3 d-flex align-items-center justify-content-center">
            <img src="${item.image}" class="img-fluid me-3" />
            <div class="text-start">
              <h5 class="mb-1">${item.title}</h5>
            </div>
          </div>
          <div class="d-none d-md-block col-md-2"><h5 class="price">EGP ${
            item.price
          }</h5></div>
          <div class="col-12 col-md-2 d-flex justify-content-center align-items-center">
            <input type="button" value="-" class="btn btn-sm minus me-1" />
            <input type="number" class="form-control quantity text-center" style="width: 60px" min="1" max="50" value="${
              item.quantity
            }" />
            <input type="button" value="+" class="btn btn-sm plus ms-1" />
          </div>
          <div class="col-12 col-md-3"><h5 class="total-price">EGP ${itemTotal.toFixed(
            2
          )}</h5></div>
          <div class="col-12 col-md-2">
            <button class="btn btn-danger delete-btn" data-bs-toggle="modal" data-bs-target="#deleteModal" data-index="${index}">
              <i class="fa fa-trash"></i>
            </button>
          </div>
        </div>`;
    });

    if (cart.length === 0) {
      output = `
        <h2>Cart List</h2>
        <section class="container d-flex justify-content-center align-items-center noCart">
        <svg xmlns="http://www.w3.org/2000/svg" height="450px" viewBox="0 -960 960 960" width="500px" fill="#FF9F00"><path d="M640-452h-35l-59-60h85l126-228H316l-60-60h529q26 0 38 21.5t-2 46.5L680-476q-5.87 11.43-14.93 17.71Q656-452 640-452ZM286.79-81Q257-81 236-102.21t-21-51Q215-183 236.21-204t51-21Q317-225 338-203.79t21 51Q359-123 337.79-102t-51 21ZM851-35 595-289H277q-38 0-56-27.5t1-59.5l70-117-86-187L46-840l43-43L894-78l-43 43ZM535-349 434-453h-95l-63 104h259Zm96-163h-85 85Zm57 431q-29 0-50.5-21.21t-21.5-51Q616-183 637.5-204t50.5-21q29 0 50.5 21.21t21.5 51Q760-123 738.5-102T688-81Z"/></svg>
        </section>
      `;
    }

    output += `</section>`;
    container.innerHTML = output;
  }

  renderCart();

  const checkoutTotal = document.getElementById("checkoutTotal");
  if (checkoutTotal) {
    checkoutTotal.textContent = total.toFixed(2);
  }

  function updateCartCounter() {
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    const userId = currentUser?.userId;
    const currentCart = (JSON.parse(localStorage.getItem("cart")) || []).filter(
      (item) => item.customerId == userId
    );

    let totalItems = 0;
    currentCart.forEach((item) => {
      totalItems += item.quantity;
    });
    const counterElement = document.querySelector(".num-cart");
    if (counterElement) {
      counterElement.textContent = totalItems;
    }
  }

  updateCartCounter();

  document.addEventListener("click", (event) => {
    if (
      event.target.classList.contains("plus") ||
      event.target.classList.contains("minus")
    ) {
      const row = event.target.closest(".cart-item");
      const index = parseInt(row.dataset.index);
      const input = row.querySelector(".quantity");
      const price = parseFloat(
        row.querySelector(".price").textContent.replace(/[^\d.]/g, "")
      );
      const totalPriceElement = row.querySelector(".total-price");

      let newQty = parseInt(input.value);
      if (event.target.classList.contains("plus")) {
        newQty++;
      } else {
        newQty--;
      }

      if (newQty >= 1 && newQty <= 50) {
        cart[index].quantity = newQty;
        localStorage.setItem("cart", JSON.stringify(cart));
        input.value = newQty;
        totalPriceElement.textContent = `EGP ${(price * newQty).toFixed(2)}`;
        updateCartCounter();
        updateCheckoutTotal();
      }
    }
  });

  document.addEventListener("change", (event) => {
    if (event.target.classList.contains("quantity")) {
      const row = event.target.closest(".cart-item");
      const index = parseInt(row.dataset.index);
      const price = parseFloat(
        row.querySelector(".price").textContent.replace(/[^\d.]/g, "")
      );
      const totalPriceElement = row.querySelector(".total-price");

      let newQty = parseInt(event.target.value) || 1;
      if (newQty >= 1 && newQty <= 50) {
        cart[index].quantity = newQty;
        localStorage.setItem("cart", JSON.stringify(cart));
        totalPriceElement.textContent = `EGP ${(price * newQty).toFixed(2)}`;
        updateCartCounter();
        updateCheckoutTotal();
      }
    }
  });

  function updateCheckoutTotal() {
    let newTotal = 0;
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    const userId = currentUser?.userId;
    const currentCart = (JSON.parse(localStorage.getItem("cart")) || []).filter(
      (item) => item.customerId == userId
    );

    currentCart.forEach((item) => {
      const cleanPrice = parseFloat(item.price.toString().replace(/,/g, ""));
      newTotal += cleanPrice * item.quantity;
    });
    if (checkoutTotal) {
      checkoutTotal.textContent = newTotal.toFixed(2);
    }
  }

  let itemToDeleteIndex = null;

  document.addEventListener("click", (event) => {
    if (event.target.closest(".delete-btn")) {
      const btn = event.target.closest(".delete-btn");
      itemToDeleteIndex = parseInt(btn.dataset.index);
    }
  });

  document.getElementById("confirmDelete").addEventListener("click", () => {
    if (itemToDeleteIndex !== null) {
      cart.splice(itemToDeleteIndex, 1);
      localStorage.setItem("cart", JSON.stringify(cart));

      renderCart();
      updateCartCounter();
      updateCheckoutTotal();
      checkCartStatus();

      const deleteModal = bootstrap.Modal.getInstance(
        document.getElementById("deleteModal")
      );
      if (deleteModal) {
        deleteModal.hide();
      }
    }
  });

  // إضافة حفظ بيانات المستخدم مع Checkbox
  const userNameInput = document.getElementById("userName");
  const emailInput = document.getElementById("email");
  const addressInput = document.getElementById("address");
  const saveInfoCheckbox = document.getElementById("save-info");

  if (userNameInput && emailInput && addressInput && saveInfoCheckbox) {
    // تحميل البيانات لو محفوظة
    const savedInfo = JSON.parse(localStorage.getItem(`userInfo_${userId}`));
    if (savedInfo) {
      userNameInput.value = savedInfo.name || "";
      emailInput.value = savedInfo.email || "";
      addressInput.value = savedInfo.address || "";
      saveInfoCheckbox.checked = true;
    }

    saveInfoCheckbox.addEventListener("change", () => {
      if (saveInfoCheckbox.checked) {
        saveUserInfo();
      } else {
        localStorage.removeItem(`userInfo_${userId}`);
      }
    });

    [userNameInput, emailInput, addressInput].forEach((input) => {
      input.addEventListener("input", () => {
        if (saveInfoCheckbox.checked) {
          saveUserInfo();
        }
      });
    });

    function saveUserInfo() {
      const userInfo = {
        name: userNameInput.value.trim(),
        email: emailInput.value.trim(),
        address: addressInput.value.trim(),
      };
      localStorage.setItem(`userInfo_${userId}`, JSON.stringify(userInfo));
    }
  }
  //  نهاية إضافة الحفظ

  // التحقق من اختيار طريقة الدفع
  document.querySelectorAll('input[name="paymentMethod"]').forEach((input) => {
    input.checked = false;
  });
  const paymentInputs = document.querySelectorAll(
    'input[name="paymentMethod"]'
  );
  const cardInfoSection = document.querySelector(".card-info");

  paymentInputs.forEach((input) => {
    input.addEventListener("change", () => {
      if (document.getElementById("CashOnDelivery").checked) {
        if (cardInfoSection) {
          cardInfoSection.classList.add("d-none");
          cardInfoSection.querySelectorAll("input").forEach((field) => {
            field.required = false;
          });
        }
      } else {
        if (cardInfoSection) {
          cardInfoSection.classList.remove("d-none");
          cardInfoSection.querySelectorAll("input").forEach((field) => {
            field.required = true;
          });
        }
      }
    });
  });

  const forms = document.querySelectorAll(".needs-validation");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      let valid = true;

      const userName = form.querySelector("#userName");
      const email = form.querySelector("#email");
      const ccNumber = form.querySelector("#cc-number");
      const cvv = form.querySelector("#cc-cvv");

      const nameRegex = /^[A-Za-z\s'-]{3,}$/;
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const ccRegex = /^\d{13,19}$/;
      const cvvRegex = /^\d{3,4}$/;

      const validateField = (input, regex) => {
        const test = regex.test(input.value.trim());
        input.classList.toggle("is-invalid", !test);
        input.classList.toggle("is-valid", test);
        return test;
      };

      if (!validateField(userName, nameRegex)) valid = false;
      if (!validateField(email, emailRegex)) valid = false;

      const isCashOnDelivery =
        document.getElementById("CashOnDelivery").checked;
      if (!isCashOnDelivery) {
        if (!validateField(ccNumber, ccRegex)) valid = false;
        if (!validateField(cvv, cvvRegex)) valid = false;
      }

      if (!form.checkValidity() || !valid) {
        event.stopPropagation();
      } else {
        const existingOrders =
          JSON.parse(localStorage.getItem("allOrders")) || [];
        cart = cart.filter((item) => item.customerId == userId);

        cart.forEach((item) => {
          existingOrders.push({
            title: item.title,
            price: +item.price,
            quantity: item.quantity,
            sellerId: item.sellerId,
            image: item.image,
            customerId: item.customerId,
            productId: 1,
          });
        });
        localStorage.setItem("allOrders", JSON.stringify(existingOrders));

        const checkoutModalElement = document.getElementById("checkoutModal");
        const checkoutModal = bootstrap.Modal.getInstance(checkoutModalElement);
        if (checkoutModal) {
          checkoutModal.hide();
        }

        const successModal = new bootstrap.Modal(
          document.getElementById("orderSuccessModal")
        );
        successModal.show();

        // const orderNumberElement = document.getElementById("orderNumber");
        // if (orderNumberElement) {
        //   orderNumberElement.textContent = Math.floor(Math.random() * 1000000);
        // }

        localStorage.removeItem("cart");
        cart = [];
        renderCart();
        updateCartCounter();
        updateCheckoutTotal();
        checkCartStatus();

        form.reset();
        form.classList.remove("was-validated");
      }

      form.classList.add("was-validated");
    });
  });

  const checkCartStatus = () => {
    const cartItems = document.querySelectorAll(".cart-item");
    const emptyCartSection = document.querySelector(".noCart");
    const payBtn = document.querySelector(".checkOut");
    const cartHead = document.querySelector(".cart-head");

    if (cartItems.length === 0) {
      if (emptyCartSection) emptyCartSection.classList.remove("d-none");
      if (payBtn) payBtn.classList.add("d-none");
      if (cartHead) cartHead.classList.add("d-none");
    } else {
      if (emptyCartSection) emptyCartSection.classList.add("d-none");
      if (payBtn) payBtn.classList.remove("d-none");
      if (cartHead) cartHead.classList.remove("d-none");
    }
  };

  checkCartStatus();

  // New Fun toast by Tarek
  function showBootstrapToast(message, type = "success") {
    const toastElement = document.getElementById("liveToast");
    const toastBody = toastElement.querySelector(".toast-body");
    const parentToast = document.getElementById("parentToast");
    parentToast.style.zIndex = "1100";
    // غير الرسالة
    toastBody.textContent = message;

    // غيّر اللون حسب النوع (success, danger, info...)
    toastElement.className = `toast align-items-center text-white bg-${type} border-0`;

    const toast = new bootstrap.Toast(toastElement);
    toast.show();
  }

  // New Fun toast by Tarek

  function checkLogin() {
    const checkOutBtn = document.querySelector(".checkOut");
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (!currentUser || currentUser === "none") {
      checkOutBtn.removeAttribute("data-bs-target");
      checkOutBtn.onclick = () => {
        // alert("GO to login First");
        showToast("You need to login First", "warning");
      };
    } else {
      checkOutBtn.setAttribute("data-bs-target", "#checkoutModal");
    }
  }
  checkLogin();
});
